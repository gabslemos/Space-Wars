function preload () {
  nave1 = loadImage('nave.png');
  nave2 = loadImage('naveinimiga.png');
  telaini =  loadImage('img-tela-inicial.jpg');
  telainst = loadImage('img-tela-inst.jpg');
  telacred = loadImage('img-tela-cred.jpg');
  
}

let fase = 0

var navejogador = {
  x: 325,
  y: 400,  
};

var tamanhoBala = 8;  // 1
var tamanhoInimigo = 25;

var Tiros = [];  // 2
var CordoTiro = true;  // 3

var Fase = 0;
var NaveInimiga = [];
var Vidas = 3;

var TempoTotal = [];

var Perdeu = false;
                      
function setup(){
  createCanvas(650, 400);
  setFrameRate(30);
  TempoTotal = millis();
  adicionaInimigo();
}

function adicionaInimigo() {
  NaveInimiga.push({
    x: random(0, 600),
    y: 0,
  }); 
}



function draw() {
  background(telaini);
  noStroke();
  
    if (fase == 0) {
    fill("#ffffff");
    push();
    textSize(40);
    textFont('Trebuchet MS');
    textStyle(BOLD)
    textAlign(CENTER)
    fill('#ffffff');
    text('SPACE WARS', 325, 110);
    fill('#ffffff');
    textStyle(NORMAL)
    textAlign(CENTER)
    textSize(17);
   
    rect(225, 150, 200, 50, 30);
    fill('#000000');
    text("JOGAR", 225, 165, 200, 50);
  if( mouseX> 225 && mouseX< 225+200 && mouseY> 145 && mouseY< 145+50){
    if(mouseIsPressed){
    fase = 1
    }
  }
      
  // Segundo botão.
  fill("#FFFFFF");
  rect(225, 225, 200, 50, 30);
  fill('#000000');
  text("INSTRUÇÕES", 225, 242, 200, 50);
  if( mouseX> 225 && mouseX< 225+200 && mouseY> 225 && mouseY< 225+50){
    if(mouseIsPressed){
    fase = 2
    }
  }
    
  // Terceiro botão.
  fill("#FFFFFF");
  rect(225, 305, 200, 50, 30);
  fill('#000000');
  text("CRÉDITOS", 225, 322, 200, 50);
  if( mouseX> 225 && mouseX< 225+200 && mouseY> 305 && mouseY< 305+50){
    if(mouseIsPressed){
    fase = 3
    }
  }        
}

  else if(fase == 1) {
    
  renova();
  clear();
  background(220);
  mostraNave();
  mostraInimigos();
  mostraBalas();
  push();
  fill(color(255, 225, 255));
  
  if (Vidas) {
    text('❤️'.repeat(Vidas), 40, 20);
  } else {
    fase = 4;
  } 
} 
  
  
  else if(fase == 2) {
    
    image(telainst, 0, 0);
    push();
    rect(60, 120, 535, 300, 10); 
    rect(173, 49, 300, 60, 10);
    textSize(32);
    textFont('Trebuchet MS');
    textStyle(BOLD)
    textAlign(CENTER)
    fill('#000000');
    textAlign(CENTER)
    text('INSTRUÇÕES 🚀', 325, 90);    
    textAlign(CENTER)
    textStyle(NORMAL)
    textSize(18);
    text('\nAperte a tecla ESPAÇO para atirar nas naves inimigas.\n\n Quando uma das naves inimigas te atingir ou passar por você,\n perdes uma vida.\n\n Você tem apenas 3 vidas, não despedice!\n\n À cada 10 segundos as naves ficam mais velozes, cuidado!', 325, 160);
    pop();
}
  
  else if(fase == 3) {
    
    image(telacred, 0, 0)
    push();
    textSize(32);
    rect(127, 120, 400, 300, 10); 
    rect(173, 49, 300, 60, 10);
    fill('#ffffff');
    textFont('Trebuchet MS');
    textStyle(BOLD)
    textAlign(CENTER)
    fill('#000000');
    text('CRÉDITOS 🚀', 325, 90);
    fill(0, 0, 0);
    textSize(20);
    textFont('Trebuchet MS');
    textStyle(BOLD)
    textAlign(CENTER)    
    fill('#000000');
    text('CRIADORA DO JOGO:', 325, 160);
    textSize(18);
    textFont('Trebuchet MS');
    textStyle(NORMAL)
    textAlign(CENTER)
    text('Gabriella Lemos', 325, 190);
    textSize(20);
    textFont('Trebuchet MS');
    textStyle(BOLD)
    textAlign(CENTER)
    text('MÚSICA:', 325, 240);
    textSize(18);
    textFont('Trebuchet MS');
    textStyle(NORMAL)
    textAlign(CENTER)
    textSize(16);
    text('Space Invaders\nyoutube.com/watch?v=k9oyDTR0EwQ', 325, 265);
    pop();
    if (keyIsDown(ESCAPE)) {
    TelaIni = true
    }
  }
  
  else if(fase == 4) {
    
    image(telaini, 0, 0)
    push();
    textSize(32);
    fill('#ffffff');
    textFont('Trebuchet MS');
    textStyle(BOLD)
    textAlign(CENTER)
    fill('#ffffff');
    text('DERROTA', 325, 90);
    fill(0, 0, 0);
    textSize(20);
    textFont('Trebuchet MS');
    textStyle(BOLD)
    textAlign(CENTER)    
    fill('#ffffff');
    text('Acho melhor tentar de novo!', 325, 160);
    ellipse(325, 240, 100, 100);
    fill('#000000');
    textSize(15);
    textFont('Trebuchet MS');
    textStyle(BOLD)
    textAlign(CENTER)
    text('TENTAR\nNOVAMENTE', 325, 235);
    if( mouseX> 275 && mouseX< 375 && mouseY> 190 && mouseY< 290){
      if(mouseIsPressed){
      TelaIni = true
      }
  }
    pop();
  }  
  
function mostraBalas() {
  push();
  
  //mudança na cor do tiro
  if (CordoTiro) {
    fill(color(255, 0, 0)); 
  } else {
    fill(color(290, 290, 0)); 
  }
  CordoTiro = !CordoTiro;
  
  Tiros.forEach(function(Balas) {
    ellipse(Balas.x, Balas.y, tamanhoBala);
  });
  
  pop();
}

function mousePressed() {
  Tiros.push({ x: navejogador.x, y: navejogador.y });
}
    
  if(mouseX>=10 && mouseX<=80 && mouseY>=460 && mouseY<=490){
    fill("#daa6ff")
      }else{
        fill("#FFFFFF")
  } 
  
  var TeclaEspaco = 32;
  if (keyCode == TeclaEspaco) {
    
    if (Perdeu) {
      Perdeu = false;
      NaveInimiga = [];
      Tiros = [];
      Vidas = 3;
      loop();
      return;      
    }
        Tiros.push({ x: navejogador.x, y: navejogador.y });
  }
  
function mostraInimigos() {
  push();
  fill(color(0, 0, 161));
  
  NaveInimiga.forEach(function(Inimigo) {
    image(nave2, Inimigo.x, Inimigo.y, 40, 40);
  });
  
  pop();
}

function mostraNave() {
  var x = navejogador.x;
  var y = navejogador.y;
  var width = 30;
  var height = 30; 
  
  rectMode(CENTER);
  push();
  translate(x, y);
  fill('#C0C0C0')
  image(nave1, -20, -35, 50, 50); 
  fill('#A9A9A9')
  rect(0, 0, 0, 0);
  pop();
}

function renovaBalass() {
  // movimenta tiros
  Tiros.forEach(function (Balas, index) {
    Balas.y -= 10;
    
    // remove tiro se ja saiu da tela
    if (Balas.y < 0) {
      Tiros.splice(index, 1);
    }
  });
}

function renovarBalas() {
  var TempoAtual = millis();
  
  // Insere inimigo a cada 2,5 segundos
  if (TempoAtual - TempoTotal > 2500) {
    TempoTotal = TempoAtual;
    adicionaInimigo();
  }
  
  // aumenta a velocidade dos inimigos a cada 10 segundos
  var velocidade = max(1, max(floor(TempoTotal / 10000), 10));
  // Movimenta inimigos e diz a velocidade que eles vem
  NaveInimiga.forEach(function (Inimigo, index) {
    Inimigo.y += 1 * velocidade;
    
    
    // verifica se foi atingido
    Tiros.forEach(function (Balas, Ind1) {
      var Colidindo = ColisaoDosRect(
        Inimigo.x, Inimigo.y, tamanhoInimigo, tamanhoInimigo,
        Balas.x, Balas.y, tamanhoBala, tamanhoBala
      );
      
      if (Colidindo) {
        NaveInimiga.splice(index, 1);
        Tiros.splice(Ind1, 1);
      }
    });
    
    if (Inimigo.y > 400) {
      NaveInimiga.splice(index, 1);
      Vidas = max(0, Vidas - 1); 
    }
  });
}

function renova() {
  renovarBalas();
  renovaBalass();
  
  var velocidade = 18;

  // Movimenta o personagem verificando os limites da tela

  if (keyIsDown(UP_ARROW)) {
    TelaIni = true;
  }
  
  if (keyIsDown(LEFT_ARROW)) {
    navejogador.x = max(0, navejogador.x - velocidade);
  }
  
  if (keyIsDown(RIGHT_ARROW)) {
    navejogador.x = min(600, navejogador.x + velocidade);
  }
}

  if (keyIsDown(ESCAPE)) {
    fase = 0
  }
}  
  
  
function ColisaoDosRect(x1, y1, w1, h1, x2, y2, w2, h2) {
  // verifica colisão de retangulos
  if (x1 + w1 >= x2 &&
      x1 <= x2 + w2 &&
      y1 + h1 >= y2 &&
      y1 <= y2 + h2) {
        return true;
  }
  
  return false;     
}


function mouseClicked() {

  if(fase == 1 && mouseX>=10 && mouseX<=80 && mouseY>=460 && mouseY<=490){
    fase = 0
  }  
  
  else if(fase == 4 && mouseX> 275 && mouseX< 375 && mouseY> 190 && mouseY< 290){
    fase = 0
    }  
}
